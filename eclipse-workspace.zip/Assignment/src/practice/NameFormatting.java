package practice;

public class NameFormatting {
    public static void main(String[] args) {
        String name = "Narendra Modi";
        
        // Convert name to uppercase
        String upperCaseName = name.toUpperCase();
        
        // Convert name to lowercase
        String lowerCaseName = name.toLowerCase();
        
        
        System.out.println("Original Name: " + name);
        System.out.println("Uppercase Name: " + upperCaseName);
        System.out.println("Lowercase Name: " + lowerCaseName);
    }
}
