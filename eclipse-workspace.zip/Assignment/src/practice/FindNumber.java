package practice;

public class FindNumber {
    public static void main(String[] args) {
        
        for (int i = 500; i <= 1000; i++) {
            
            if (i == 808) {
                System.out.println("Number found: " + i);
            }
        }
    }
}