package practice;

public class FloatNumber {

	
	public static float add(float a, float b)
	
	{
		float sum = a+b;
		return sum;
	}
	
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		//FloatNumber.add(8.6f, 9.7f);
		System.out.println("Sum of float number is "+FloatNumber.add(8.6f, 9.7f));
	}

}
