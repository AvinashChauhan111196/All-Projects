package com.maveric.project.auths;

public class ClientAuthConstant {
	
	public static String SCOPE ="offline_access";
	public static String GRANT_TYPE ="password";
	public static String USER_NAME="api-user4@iwt.net";
	public static String PASSWORD="b3z0nV0cLO";
	public static String CLIENT_ID="0oahdhjkutaGcIK2M4x6";
	public static String BEARER_TOKEN;
	
}