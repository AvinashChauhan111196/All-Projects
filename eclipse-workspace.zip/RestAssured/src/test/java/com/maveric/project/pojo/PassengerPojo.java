package com.maveric.project.pojo;

public class PassengerPojo {

	private String id;
    private String name;
    private int trips;
    private int airline;
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public int getTrips() {
		return trips;
	}
	public void setTrips(int trips) {
		this.trips = trips;
	}
	public int getAirline() {
		return airline;
	}
	public void setAirline(int airline) {
		this.airline = airline;
	}
    
}
