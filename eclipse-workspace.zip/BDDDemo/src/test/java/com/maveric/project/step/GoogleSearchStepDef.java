package com.maveric.project.step;

import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

public class GoogleSearchStepDef {

	@Given("User should open Google search page")
	public void user_should_open_google_search_page() {
	    // Write code here that turns the phrase above into concrete actions
	    throw new io.cucumber.java.PendingException();
	}

	@When("User enterd {string} in search box")
	public void user_enterd_in_search_box(String string) {
	    // Write code here that turns the phrase above into concrete actions
	    throw new io.cucumber.java.PendingException();
	}

	@When("click on submit button")
	public void click_on_submit_button() {
	    // Write code here that turns the phrase above into concrete actions
	    throw new io.cucumber.java.PendingException();
	}

	@Then("Multiple Links should be displayed on {string} topic")
	public void multiple_links_should_be_displayed_on_topic(String string) {
	    // Write code here that turns the phrase above into concrete actions
	    throw new io.cucumber.java.PendingException();
	}

	@When("User enterd cities name {string}  in search box")
	public void user_enterd_cities_name_in_search_box(String string) {
	    // Write code here that turns the phrase above into concrete actions
	    throw new io.cucumber.java.PendingException();
	}

	@Then("map should be display between {string} cities along with distance in KM")
	public void map_should_be_display_between_cities_along_with_distance_in_km(String string) {
	    // Write code here that turns the phrase above into concrete actions
	    throw new io.cucumber.java.PendingException();
	}

	
}
