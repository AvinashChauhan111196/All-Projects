package core;

public class DataType {

	static boolean b;
	static int i;
	static float f;
	static double d;
	static char c;
	static short s;
	static long l;
	static byte e;
	static String str;
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		
		
		System.out.println(b);
		System.out.println(i);
		System.out.println(f);
		System.out.println(d);
		System.out.println(c);
		System.out.println(s);
		System.out.println(l);
		System.out.println(e);
		System.out.println(str);

	}

}
