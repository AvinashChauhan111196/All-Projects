package core;

public class TestImplement implements TestInterface {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		TestImplement ti = new TestImplement();
		ti.testDefault();
	}

}
