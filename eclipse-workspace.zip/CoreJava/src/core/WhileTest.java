package core;

public class WhileTest {

	
	public void test() {
		
		  int i=1;  
		    while(i<=12){  
		        System.out.println(i);  
		    i++;  
		    }  
		
	}
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		WhileTest w = new WhileTest();
		w.test();

	}

}
