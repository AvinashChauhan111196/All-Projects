package core;

public interface TestInterface {

	
	default void testDefault()
	{
		System.out.println("This is default method");
	}
	
}
