package core;

public class Test {

	
	
	public static void main(String args[])
	{
		int x=10;
		double a= 10.5;
		String b = "welcome";
		  char c='m';
	   boolean d= false;
	   
	   System.out.println(x);
	   System.out.println(a);
	   System.out.println(b);
	   System.out.println(c);
	   System.out.println(d);
	}
}
