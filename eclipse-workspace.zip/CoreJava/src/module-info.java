/**
 * 
 */
/**
 * @author avinashkc
 *
 */
module CoreJava {
}