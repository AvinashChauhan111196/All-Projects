package com.maveric.project.pojos;

public class RegisterUnSuccessPojo {

	String email;

	public RegisterUnSuccessPojo(String email) {
		super();
		this.email = email;
	}

	public RegisterUnSuccessPojo() {
	
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}
	
	
}
