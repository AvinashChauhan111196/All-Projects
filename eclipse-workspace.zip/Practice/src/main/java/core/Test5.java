package core;

public class Test5 {

	void test5()
	{
		
	}
}

abstract class Test6 
{
 void test6()
 {
	 
 }
}

final class Test7
{
void test7()
{
	
}

}


class Test8
{
void test8()
{
	
}
}