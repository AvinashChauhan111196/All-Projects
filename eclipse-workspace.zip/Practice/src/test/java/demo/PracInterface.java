package demo;

public interface PracInterface {

	
	public void mult();
	public void div();
	public void sub();
	public void add();
	public void xxx();
	
	
}
