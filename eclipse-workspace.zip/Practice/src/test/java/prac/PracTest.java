package prac;

public class PracTest {

	public static void main(String args[])
	{
		int i=1;
		int j=2;
		int cal = i%j;
		
		
		System.out.println("The q is " +cal);
		
	}
}
