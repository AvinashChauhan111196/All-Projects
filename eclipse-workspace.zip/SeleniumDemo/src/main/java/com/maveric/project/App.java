package com.maveric.project;

import com.maveric.project.utils.DriverFactory;

/**
 * Hello world!
 *
 */
public class App {
	public static void main(String[] args) {
		
		DriverFactory.getDriver();

	}
}
