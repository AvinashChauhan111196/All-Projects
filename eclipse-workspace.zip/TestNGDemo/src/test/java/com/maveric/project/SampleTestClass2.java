package com.maveric.project;

import org.testng.annotations.Test;

public class SampleTestClass2 {
  
}
